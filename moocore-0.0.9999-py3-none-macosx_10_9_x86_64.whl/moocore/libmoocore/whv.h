#ifndef WHV_H
#define WHV_H
#include <stdlib.h>
double rect_weighted_hv2d(double *data, size_t n, double * rectangles, size_t rectangles_nrow);

#endif // WHV_H
